H_control_compare.py: compare the proposed method with other solutions.

H_control_tank.py: a quadrupt tank example

H_control_large_scale: large scale mass-spring-damper examples -- change the system scale by setting "num_mass"

H_control_group.py: using group lasso
